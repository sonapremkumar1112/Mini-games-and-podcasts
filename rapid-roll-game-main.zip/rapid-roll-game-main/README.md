rapid roLl game
